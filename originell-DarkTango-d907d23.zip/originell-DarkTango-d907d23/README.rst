=========
DarkTango
=========

--
is
--

a TextMate Theme based on the standard theme *Blackboard* mixed with Geany's DarkTango_..

This also works with Sublime Text 2 (tested with Alpha Build 2051 to 2060)

Screenshot included. Hope you enjoy it.

.. image:: http://github.com/originell/DarkTango/raw/master/tm_screenie.png
.. image:: http://github.com/originell/DarkTango/raw/master/sublime_screenie.png

Installation
============


TextMate
--------

Just grab the theme file and drag it into
    
    ~/Library/Application Support/TextMate/Themes/

Sublime Text 2
--------------

Either you go to `Settings` -> `Default/User File Preferences` and set an absolute Path *color-scheme* or you simply drag the tmTheme to

    ~/Library/Application Support/Sublime Text 2/Packages/Color Scheme - Default/

and restart Sublime Text 2.

.. _DarkTango: http://code.google.com/p/geany-dark-scheme/
